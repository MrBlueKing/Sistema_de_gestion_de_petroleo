<?php

use Illuminate\Support\Facades\Log;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\Api\AuthController;
use App\Http\Controllers\Api\UserController;
use App\Http\Controllers\Api\BodegaController;
use Illuminate\Support\Facades\DB;
use App\Http\Controllers\Api\CategoriaMaquinaController;
use App\Http\Controllers\Api\CategoriasChartController;
use App\Http\Controllers\Api\CombustibleController;
use App\Http\Controllers\Api\ConsumoController;
use App\Http\Controllers\Api\ConsumoProyeccionController;
use App\Http\Controllers\Api\EmpresaExternaController;
use App\Http\Controllers\Api\FaenaController;
use App\Http\Controllers\Api\PersonalInternoController;
use App\Http\Controllers\Api\MaquinaInternaController;
use App\Http\Controllers\Api\IngresoPetroleoController;
use App\Http\Controllers\Api\EstanqueController;
use App\Http\Controllers\Api\InformeKpiController;
use App\Http\Controllers\Api\InformesController;
use App\Http\Controllers\Api\KpiCalculadoraController;
use App\Http\Controllers\Api\KpiCalculoController;
use App\Http\Controllers\Api\KpiHistoricoController;
use App\Http\Controllers\Api\KpiValoresEntradaController;
use App\Http\Controllers\Api\MantenimientoController;
use App\Http\Controllers\Api\PersonalExternoController;
use App\Http\Controllers\Api\ProyeccionConsumoController;
use App\Http\Controllers\Api\ReporteController;
use App\Http\Controllers\Api\TonelajeController;
use App\Http\Controllers\DatabaseCheckController;
use App\Http\Controllers\Api\ProduccionController;
use App\Http\Controllers\Api\VerificacionIngresosController;
use App\Http\Controllers\Api\MaquinasExternasController;
use App\Http\Controllers\Api\SolicitantesOptimizadoController;
use App\Http\Controllers\Api\ConsumoCategoriasController;
use App\Http\Controllers\Api\MaquinaPermisosController;
use App\Http\Controllers\Api\RolController;
use App\Http\Controllers\Api\TrasvasijeController;
use App\Http\Controllers\ApiPdf\ConsumosPdfController;
use App\Http\Controllers\Api\UserFaenaController;

/*
|--------------------------------------------------------------------------
| 🔐 RUTAS PÚBLICAS (NO REQUIEREN AUTENTICACIÓN)
|--------------------------------------------------------------------------
*/

// Autenticación básica
Route::post('/login', [AuthController::class, 'login']);
Route::post('/register', [AuthController::class, 'register']);


Route::get('/faenasDisponibles', [FaenaController::class, 'getFaenasDisponibles']);
// Rutas para verificación de ingresos

Route::get('/verificacion-ingresos', [VerificacionIngresosController::class, 'index']);

// Obtener detalle de un ingreso específico
Route::get('/verificacion-ingresos{id}', [VerificacionIngresosController::class, 'show']);

Route::get('/estadisticas', [VerificacionIngresosController::class, 'estadisticas']);


// Obtener resumen de errores por período
Route::get('/verificacion-ingresos/resumen', [VerificacionIngresosController::class, 'resumen']);

// 🆕 NUEVAS RUTAS PARA CÁLCULO DE STOCK DETALLADO
Route::get('/verificacion-ingresos/calculo-stock', [VerificacionIngresosController::class, 'calcularStockEnFecha']);
Route::get('/verificacion-ingresos/resumen-detallado', [VerificacionIngresosController::class, 'resumenDetalladoPeriodo']);

/*
|--------------------------------------------------------------------------
| 🔒 RUTAS PROTEGIDAS (REQUIEREN AUTENTICACIÓN)
|--------------------------------------------------------------------------
*/

Route::middleware('auth:sanctum')->group(function () {

    /*
    |--------------------------------------------------------------------------
    | 🔐 AUTENTICACIÓN Y USUARIO
    |--------------------------------------------------------------------------
    */
    Route::post('/logout', [AuthController::class, 'logout']);

    Route::get('/user', function (Request $request) {
        $user = $request->user();
        $user->load('faena', 'rol', 'faenaActiva');

        // Si tiene faena_activa_id, usar esa como id_faena para compatibilidad
        if ($user->faena_activa_id) {
            // Crear una copia del usuario con id_faena actualizado
            $userData = $user->toArray();
            $userData['id_faena'] = $user->faena_activa_id;

            // Cargar la faena activa como 'faena'
            $faenaActiva = \App\Models\Faena::find($user->faena_activa_id);
            if ($faenaActiva) {
                $userData['faena'] = $faenaActiva;
            }

            return response()->json($userData);
        }

        return response()->json($user);
    });

    Route::get('/usuarios/recientes', [UserController::class, 'recientes']);
    Route::get('/user/{id}', [UserController::class, 'show']);

    /*
    |--------------------------------------------------------------------------
    | 🏭 GESTIÓN DE FAENAS DEL USUARIO
    |--------------------------------------------------------------------------
    */
    Route::prefix('user-faenas')->group(function () {
        Route::get('/', [UserFaenaController::class, 'getFaenas']);
        Route::post('/cambiar-activa', [UserFaenaController::class, 'cambiarFaenaActiva']);
        Route::post('/asignar', [UserFaenaController::class, 'asignarFaena']);
        Route::delete('/remover', [UserFaenaController::class, 'removerFaena']);
    });

    /*
    |--------------------------------------------------------------------------
    | 🏭 FAENAS - Endpoint general
    |--------------------------------------------------------------------------
    */
    Route::get('/faenas', [FaenaController::class, 'index']);


    /*
    |--------------------------------------------------------------------------
    | 🦖 Rol
    |--------------------------------------------------------------------------
    */
    Route::prefix('/')->group(function () {
        Route::get('/rol', [RolController::class, 'index']);
    });

    /*
    |--------------------------------------------------------------------------
    | 📦 BODEGA
    |--------------------------------------------------------------------------
    */
    Route::prefix('bodega')->group(function () {
        Route::get('/maquinarias', [BodegaController::class, 'obtenerMaquinarias']);
        Route::get('/personal', [BodegaController::class, 'index']);
        Route::get('/personal-invalidos', [BodegaController::class, 'rutInvalidos']);
        Route::get('/maquinarias-lista', [BodegaController::class, 'getMaquinarias']);
    });

    /*
    |--------------------------------------------------------------------------
    | 👨‍💼 PERSONAL INTERNO
    |--------------------------------------------------------------------------
    */
    Route::prefix('personal-interno')->group(function () {
        Route::get('/solicitantes', [PersonalInternoController::class, 'listarSolicitantes']);
        Route::post('/registrar', [PersonalInternoController::class, 'register']);
        Route::get('/', [PersonalInternoController::class, 'index']);
        Route::post('/asignar-permiso', [PersonalInternoController::class, 'asignarPermisoSolicitante']);
        Route::get('/interno-externo', [PersonalInternoController::class, 'indexInternoExterno']);
    });


    /*
    |--------------------------------------------------------------------------
    | 👨‍💼 BUSQUEDA POR SOLICITANTES - FAENAS
    |--------------------------------------------------------------------------
    */
    Route::get('/solicitantes-internos-faena', [SolicitantesOptimizadoController::class, 'internosPorFaena']);
    Route::get('/solicitantes-externos-faena', [SolicitantesOptimizadoController::class, 'externosPorFaena']);
    Route::get('/solicitantes-por-faena', [SolicitantesOptimizadoController::class, 'porFaenaYTipo']);



    /*
    |--------------------------------------------------------------------------
    | 🏢 EMPRESAS EXTERNAS Y PERSONAL EXTERNO
    |--------------------------------------------------------------------------
    */
    Route::prefix('empresas-externas')->group(function () {
        Route::post('/', [EmpresaExternaController::class, 'store']);
        Route::get('/disponibles', [EmpresaExternaController::class, 'index']);
    });

    Route::prefix('personal-externo')->group(function () {
        Route::post('/registrar', [PersonalExternoController::class, 'store']);
        Route::get('/', [PersonalExternoController::class, 'index']);
    });

    /*
    |--------------------------------------------------------------------------
    | 🚛 MAQUINARIAS
    |--------------------------------------------------------------------------
    */
    Route::apiResource('categorias-maquinas', CategoriaMaquinaController::class);
    Route::get('/categorias', [CategoriaMaquinaController::class, 'index']);

    Route::prefix('maquinas-internas')->group(function () {
        Route::post('/', [MaquinaInternaController::class, 'store']);
        Route::get('/registradas', [MaquinaInternaController::class, 'index']);
        Route::get('/con-permisos', [MaquinaInternaController::class, 'indexConPermisos']);
    });


    // Rutas para máquinas externas
    Route::get('/maquinas-externas', [MaquinasExternasController::class, 'index']);
    Route::get('/maquinas-externas/categoria/{idCategoria}', [MaquinasExternasController::class, 'porCategoria']);



    /*
    |--------------------------------------------------------------------------
    | 🏭 FAENAS
    |--------------------------------------------------------------------------
    */
    Route::prefix('faenas')->group(function () {
        Route::get('/', [FaenaController::class, 'index']);
        Route::get('/disponibles/{id_solicitante}', [FaenaController::class, 'faenasDisponibles']);
        Route::get('/permisos', [FaenaController::class, 'getPermisosFaenas']);
        Route::get('/verificar-permiso', [FaenaController::class, 'verificarPermiso']);
        Route::get('/disponibles-general', [FaenaController::class, 'getFaenasDisponibles']);
    });

    /*
    |--------------------------------------------------------------------------
    | ⛽ GESTIÓN PETROLERA
    |--------------------------------------------------------------------------
    */
    Route::prefix('petroleo')->group(function () {
        // Ingresos de petróleo
        Route::prefix('ingresos')->group(function () {
            Route::get('/', [IngresoPetroleoController::class, 'index']);
            Route::post('/', [IngresoPetroleoController::class, 'store']);
            Route::get('/ingresos-petroleo/resumen-faenas', [IngresoPetroleoController::class, 'getResumenPorFaenas']);
        });

        // Estanques
        Route::prefix('estanques')->group(function () {
            Route::get('/{id_faena}', [EstanqueController::class, 'estanquesPorFaena']);
            Route::post('/calcular-litros', [EstanqueController::class, 'calcularLitrosPetroleo']);
            Route::get('/capacidad-disponible/{id_faena}', [EstanqueController::class, 'capacidadDisponible']);
        });
    });

    Route::get('/ingresos-petroleo', [IngresoPetroleoController::class, 'index']);
    Route::post('/ingresos-petroleo', [IngresoPetroleoController::class, 'store']);

    // CASO 1: Recepción tradicional (Copec → Estanques fijos)
    Route::post('/recepciones/estanques-fijos', [IngresoPetroleoController::class, 'storeRecepcionFijos']);

    // CASO 2: Recepción móvil (Copec → Estanque móvil)
    Route::post('/recepciones/estanque-movil', [IngresoPetroleoController::class, 'storeRecepcionMovil']);


    //Route::get('/capacidad-disponible/{idFaena}', [IngresoPetroleoController::class, 'capacidadDisponible']);
    Route::get('/recepciones/stats', [IngresoPetroleoController::class, 'getStats']);
    Route::get('/recepciones', [IngresoPetroleoController::class, 'getRecepciones']);


    // ========================================
    // 🔄 SISTEMA DE TRASVASIJES
    // ========================================

    Route::middleware('auth:sanctum')->prefix('trasvasijes')->group(function () {

        // Dashboard y estadísticas
        Route::get('/dashboard', [TrasvasijeController::class, 'dashboard']);
        Route::get('/estadisticas', [TrasvasijeController::class, 'estadisticas']);
        Route::get('/datos-formulario', [TrasvasijeController::class, 'datosFormulario']);

        // Listado general de trasvasijes
        Route::get('/', [TrasvasijeController::class, 'index']);

        // Registrar trasvasijes
        Route::post('/movil-a-fijo', [TrasvasijeController::class, 'registrarMovilAFijo']);
        Route::post('/fijo-a-movil', [TrasvasijeController::class, 'registrarFijoAMovil']);

        // Verificar trasvasijes móvil→fijo
        Route::post('/movil-a-fijo/{id}/verificar', [TrasvasijeController::class, 'verificarMovilAFijo']);

        // Obtener detalle específico
        Route::get('/{tipo}/{id}', [TrasvasijeController::class, 'show'])
            ->where('tipo', 'movil-a-fijo|fijo-a-movil');
    });

    // Rutas legacy para compatibilidad (si las necesitas)
    Route::middleware('auth:sanctum')->group(function () {
        // Alias cortos
        Route::post('/trasvasije-movil-fijo', [TrasvasijeController::class, 'registrarMovilAFijo']);
        Route::post('/trasvasije-fijo-movil', [TrasvasijeController::class, 'registrarFijoAMovil']);
        Route::get('/trasvasijes-dashboard', [TrasvasijeController::class, 'dashboard']);
    });


    /*
    |--------------------------------------------------------------------------
    | 📊 KPIs Y ANÁLISIS
    |--------------------------------------------------------------------------
    */
    Route::prefix('kpi')->group(function () {
        Route::apiResource('valores-entrada', KpiValoresEntradaController::class);
        Route::get('/informes', [InformeKpiController::class, 'index']);
        Route::get('/informes/test', [InformeKpiController::class, 'test']);
        Route::get('/informes/mes-anterior', [InformeKpiController::class, 'obtenerValoresMesAnterior']);

        // Cálculos de KPIs
        Route::post('/calcular', [KpiCalculoController::class, 'calcular']);
        Route::get('/datos-mes-anterior', [InformeKpiController::class, 'obtenerValoresMesAnterior']);
        Route::get('/faenas-disponibles', [KpiCalculoController::class, 'getFaenasDisponibles']);
        Route::get('/comparativos', [KpiCalculoController::class, 'obtenerKpisComparativos']);
        Route::get('/costo-petroleo-sin-ultimos', [KpiCalculoController::class, 'getCostoPetroleoSinUltimosConsumos']);

        // Valores de entrada KPI
        Route::get('/verificar-permiso', [KpiValoresEntradaController::class, 'verificarPermiso']);
        Route::get('/historial', [KpiValoresEntradaController::class, 'obtenerHistorial']);
        Route::get('/historial-general', [KpiValoresEntradaController::class, 'getHistorialGeneral']);
        Route::get('/historial/faena/{idFaena}', [KpiValoresEntradaController::class, 'getHistorialPorFaena']);
        Route::get('/estadisticas-por-faena', [KpiValoresEntradaController::class, 'getEstadisticasPorFaena']);
        Route::get('/totales-acumulados', [KpiValoresEntradaController::class, 'getTotalesAcumulados']);
        Route::get('/historial-filtrado', [KpiValoresEntradaController::class, 'getHistorialFiltrado']);

        // Informes específicos
        Route::get('/consumo-maquinas', [InformesController::class, 'getConsumoMaquinas']);
        Route::get('/balance-combustible', [InformesController::class, 'getBalanceCombustible']);
    });

    // Rutas para Consumos
    Route::prefix('consumos')->group(function () {
        // Ruta original para consumos
        Route::post('/', [ConsumoController::class, 'store']);

        // ✅ NUEVA RUTA: Consumos multi-estanque
        Route::post('/multi', [ConsumoController::class, 'storeMultiEstanque']);

        // Nueva Ruta: para el apartado de consumo(bombero navigation) se obtiene datos del ultimo consumo de una maquina especifica
        Route::get('/ultima-medicion', [ConsumoController::class, 'getUltimaMedicion']);

        // Otras rutas de consumos
        Route::get('/recientes', [ConsumoController::class, 'getConsumosRecientes']);
        Route::get('/', [ConsumoController::class, 'getConsumos']);

        //Rutas para obtener los ultimos dos consumos de una maquina especifica independientemente de la faena
        Route::get('/ultimos/{id_maquina}', [ConsumoController::class, 'getUltimosConsumosMaquina']);
    });

    /*
    |--------------------------------------------------------------------------
    | 📈 PROYECCIONES DE CONSUMO
    |--------------------------------------------------------------------------
    */
    Route::prefix('proyeccion-consumo')->group(function () {
        Route::get('/', [ProyeccionConsumoController::class, 'getProyeccionAvanzada']);
        Route::get('/equipos', [ProyeccionConsumoController::class, 'getEquiposConUltimoConsumo']);
        Route::get('/ayer', [ProyeccionConsumoController::class, 'getMaquinasConConsumoHastaAyer']);
        Route::get('/resumen-fecha', [ProyeccionConsumoController::class, 'getResumenConsumoParaFecha']);
        Route::get('/rango', [ProyeccionConsumoController::class, 'getMaquinasConConsumoEnRango']);
        Route::get('/reporte', [ProyeccionConsumoController::class, 'getReporteProyeccionPorPeriodo']);
        Route::get('/test', [ProyeccionConsumoController::class, 'getKpisConProyeccion']);
    });

    Route::prefix('proyeccion-consumo2')->group(function () {
        Route::post('/proyeccion', [ConsumoProyeccionController::class, 'calcularConsumoRango']);
        Route::post('/proyeccion/maquina/{id}', [ConsumoProyeccionController::class, 'calcularMaquinaIndividual']);
        Route::get('/configuracion', [ConsumoProyeccionController::class, 'obtenerConfiguracion']);
    });

    /*
    |--------------------------------------------------------------------------
    | ⚖️ TONELAJES
    |--------------------------------------------------------------------------
    */
    Route::prefix('tonelajes')->group(function () {
        Route::get('/faenas', [TonelajeController::class, 'getFaenas']);
        Route::get('/faenas/{id}/padrones', [TonelajeController::class, 'getPadrones']);
        Route::get('/registros', [TonelajeController::class, 'getRegistros']);

        // CRUD básico de tonelajes
        Route::get('/', [TonelajeController::class, 'index']);
        Route::post('/', [TonelajeController::class, 'store']);
        Route::get('/{id}', [TonelajeController::class, 'show']);
        Route::put('/{id}', [TonelajeController::class, 'update']);
        Route::delete('/{id}', [TonelajeController::class, 'destroy']);
        Route::get('/{id}/historial', [TonelajeController::class, 'getHistorial']);
        Route::get('/{id}/puede-editar', [TonelajeController::class, 'puedeEditar']);
    });

    /*
    |--------------------------------------------------------------------------
    | 👨‍💼 Rutas para calcular Kpis Gerente(Probando)
    |--------------------------------------------------------------------------
    */

    Route::get('/tonelajes-kpis', [TonelajeController::class, 'getFaenas']);
    Route::get('/informes-kpi', [InformeKpiController::class, 'index']);
    Route::get('/informes-kpi/test', [InformeKpiController::class, 'test']);
    Route::get('/informes-kpi/mes-anterior', [InformeKpiController::class, 'obtenerValoresMesAnterior']);
    Route::get('/informes-kpi/consumo-maquinas', [InformesController::class, 'getConsumoMaquinas']);
    Route::get('/informes-kpi/balance-combustible', [InformesController::class, 'getBalanceCombustible']);
    Route::get('/informes-kpi/verificar-precios-consumos', [InformesController::class, 'verificarPreciosConsumos']);



    /*
    |--------------------------------------------------------------------------
    | 🔧 MANTENIMIENTO
    |--------------------------------------------------------------------------
    */
    Route::prefix('mantenimiento')->group(function () {
        Route::get('/', [MantenimientoController::class, 'index']);
        Route::post('/', [MantenimientoController::class, 'store']);
        Route::get('/{id}/historial', [MantenimientoController::class, 'historial']);
        Route::put('/{id}/operativa', [MantenimientoController::class, 'marcarOperativa']);
        Route::get('/estadisticas', [MantenimientoController::class, 'estadisticas']);
        Route::post('/programar', [MantenimientoController::class, 'programarMantenimiento']);
        Route::get('/alertas', [MantenimientoController::class, 'obtenerAlertas']);
        Route::get('/reporte/export', [MantenimientoController::class, 'exportarReporte']);
        Route::get('/costos', [MantenimientoController::class, 'obtenerCostos']);
        Route::get('/dashboard', [MantenimientoController::class, 'dashboard']);
    });

    Route::prefix('maquinas')->group(function () {
        Route::get('/', [MantenimientoController::class, 'obtenerMaquinas']);
        Route::get('/{id}', [MantenimientoController::class, 'obtenerMaquina']);
        Route::put('/{id}/configuracion', [MantenimientoController::class, 'actualizarConfiguracion']);
        Route::get('/{id}/metricas', [MantenimientoController::class, 'obtenerMetricas']);
    });

    /*
    |--------------------------------------------------------------------------
    | 📊 GESTIÓN DE PRODUCCIÓN
    |--------------------------------------------------------------------------
    */
    Route::prefix('produccion')->controller(ProduccionController::class)->group(function () {
        Route::get('/dashboard', 'dashboard');
        Route::get('/faena/{id}', 'getEstadisticasFaena');
        Route::get('/por-faena/{dias?}', 'getProduccionPorFaena');
        Route::get('/por-planta', 'getProduccionPorPlanta');
        Route::get('/top-padrones/{limite?}', 'getTopPadronesProductores');
        Route::get('/tendencia/{dias?}', 'getTendenciaProduccion');
        Route::get('/diaria/ultima', 'getProduccionDiariaUltima');
        Route::get('/diaria', 'getProduccionDiariaPorFecha');
        Route::get('/faenas-prod', 'getFaenas');
        Route::get('/filtrada', 'getProduccionFiltrada');
    });

    /*
    |--------------------------------------------------------------------------
    | 🛢️ CONTROL DE COMBUSTIBLE
    |--------------------------------------------------------------------------
    */
    Route::prefix('combustible')->controller(CombustibleController::class)->group(function () {
        // Dashboard principal
        Route::get('/dashboard/{idFaena?}', 'dashboard');
        Route::get('/dashboard', 'dashboard');

        // Stock y estanques
        Route::get('/stock/general', 'getStockGeneral');
        Route::get('/stock/por-faena', 'getStockPorFaena');
        Route::get('/stock/detalle/{idFaena}', 'getDetalleStockFaena');
        Route::get('/estanques/capacidad', 'getCapacidadEstanques');
        Route::get('/estanques/alertas', 'getAlertasStock');

        // Ingresos de combustible
        Route::get('/ingresos/historial', 'getHistorialIngresos');
        Route::get('/ingresos/ultimos/{dias?}', 'getIngresosRecientes');
        Route::get('/ingresos/estadisticas', 'getEstadisticasIngresos');
        Route::get('/ingresos/por-periodo', 'getIngresosPorPeriodo');

        // Consumos
        Route::get('/consumos/resumen', 'getResumenConsumos');
        Route::get('/consumos/por-equipo', 'getConsumosPorEquipo');
        Route::get('/consumos/por-faena', 'getConsumosPorFaena');
        Route::get('/consumos/tendencia', 'getTendenciaConsumos');
        Route::get('/consumos/eficiencia', 'getEficienciaConsumos');
        Route::get('/consumos/ultimos/{dias?}', 'getConsumosRecientes');

        // Análisis financiero
        Route::get('/costos/resumen', 'getResumenCostos');
        Route::get('/costos/por-periodo', 'getCostosPorPeriodo');
        Route::get('/costos/proyeccion', 'getProyeccionCostos');
        Route::get('/precios/historial', 'getHistorialPrecios');

        // Análisis y proyecciones
        Route::get('/analisis/rendimiento', 'getAnalisisRendimiento');
        Route::get('/proyecciones/stock', 'getProyeccionStock');
        Route::get('/alertas/sistema', 'getAlertasSistema');
        Route::get('/movimientos/historial', 'getHistorialMovimientos');

        // Reportes específicos
        Route::get('/reportes/balance', 'getReporteBalance');
        Route::get('/reportes/consumo-detallado', 'getReporteConsumoDetallado');
        Route::get('/reportes/eficiencia-equipos', 'getReporteEficienciaEquipos');
    });

    /*
    |--------------------------------------------------------------------------
    | 📄 REPORTES PDF
    |--------------------------------------------------------------------------
    */
    Route::prefix('reportes')->group(function () {
        Route::get('/prueba', [ReporteController::class, 'generarReportePrueba']);
        Route::get('/pdf', [ReporteController::class, 'generarPDF']);
        Route::post('/completo', [ReporteController::class, 'generarReporteCompleto']);
        Route::post('/consumos', [ReporteController::class, 'reporteConsumosPorPeriodo']);
        Route::post('/stock', [ReporteController::class, 'reporteStockActual']);
        Route::post('/rendimiento', [ReporteController::class, 'reporteRendimientoMaquinas']);
        Route::post('/preview', [ReporteController::class, 'previewReporte']);
    });

    /*
    |--------------------------------------------------------------------------
    | 🧪 TESTING Y VERIFICACIÓN (SOLO PARA DESARROLLO)
    |--------------------------------------------------------------------------
    */
    Route::get('/check-databases', [DatabaseCheckController::class, 'check']);

    Route::get('/test-bodega', function () {
        try {
            $result = DB::connection('bodega')->table('personal')->limit(1)->get();
            return response()->json([
                'success' => true,
                'data' => $result
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ]);
        }
    });

    /*
    |--------------------------------------------------------------------------
    | 📂 CATEGORÍAS (MANTENIMIENTO)
    |--------------------------------------------------------------------------
     OJOOOOOOOOOOO QUE SE CAMBIO POR PROBLEMAS CON CATEGORIAS MAQUINAS*/
    Route::prefix('categoriasMantenimiento')->group(function () {
        Route::get('/', [MantenimientoController::class, 'obtenerCategorias']);
        Route::post('/', [MantenimientoController::class, 'crearCategoria']);
        Route::put('/{id}', [MantenimientoController::class, 'actualizarCategoria']);
        Route::delete('/{id}', [MantenimientoController::class, 'eliminarCategoria']);
    });

    // Grupo de rutas para consumo por categorías
    Route::prefix('consumo-categorias')->group(function () {

        // Endpoint principal: Calcular consumo con datos confirmados + simulación
        Route::post('/calcular', [ConsumoCategoriasController::class, 'calcularConsumoPorCategorias']);

        // Obtener parámetros de todas las categorías
        Route::get('/parametros', [ConsumoCategoriasController::class, 'obtenerParametrosCategorias']);

        // Actualizar parámetros CHC y HRC de una categoría
        Route::put('/{id}/parametros', [ConsumoCategoriasController::class, 'actualizarParametrosCategoria']);

                
    });


    // Rutas legacy que mantienes por compatibilidad (considera migrar estas)
    Route::get('/maquinarias-bodega', [BodegaController::class, 'obtenerMaquinarias']);
    Route::get('/personal-bodega', [BodegaController::class, 'index']);
    Route::get('/personal-bodega-invalidos', [BodegaController::class, 'rutInvalidos']);
    Route::get('/maquinarias', [BodegaController::class, 'getMaquinarias']);
    Route::get('/maquinarias-con-vista-previa', [BodegaController::class, 'getMaquinariasConVistaPrevia']);
    Route::get('/solicitantes', [PersonalInternoController::class, 'listarSolicitantes']);
    Route::post('/registrarUsuarioInterno', [PersonalInternoController::class, 'register']);
    Route::get('/personal-internos', [PersonalInternoController::class, 'index']);
    Route::post('/asignarPermisoSolicitante', [PersonalInternoController::class, 'asignarPermisoSolicitante']);
    Route::get('/personal-internos-externos', [PersonalInternoController::class, 'indexInternoExterno']);
    Route::post('/ingresos-empresas-externas', [EmpresaExternaController::class, 'store']);
    Route::get('/empresas-disponibles', [EmpresaExternaController::class, 'index']);
    Route::post('/registrar-personal-externo', [PersonalExternoController::class, 'store']);
    Route::get('/personal-externos', [PersonalExternoController::class, 'index']);
    Route::post('/maquinas-internas', [MaquinaInternaController::class, 'store']);
    Route::get('/maquinas-internas-registradas', [MaquinaInternaController::class, 'index']);
    Route::get('/maquinas-internas-permiso', [MaquinaInternaController::class, 'indexConPermisos']);
    Route::get('/faenas-disponibles/{id_solicitante}', [FaenaController::class, 'faenasDisponibles']);
    Route::get('/permisosFaenas', [FaenaController::class, 'getPermisosFaenas']);
    Route::get('/verificarPermiso', [FaenaController::class, 'verificarPermiso']);
    Route::get('/faenasDisponibles', [FaenaController::class, 'getFaenasDisponibles']);
    Route::get('/estanques/{id_faena}', [EstanqueController::class, 'estanquesPorFaena']);
    Route::get('/estanques-fijo/{id_faena}', [EstanqueController::class, 'estanquesFijoPorFaena']);

    Route::get('/estanques-moviles/{id_faena}', [EstanqueController::class, 'getEstanquesMoviles']);


    Route::post('/calcular-litros-petroleo', [EstanqueController::class, 'calcularLitrosPetroleo']);
    Route::get('/capacidad-disponible/{id_faena}', [EstanqueController::class, 'capacidadDisponible']);

    // Rutas CRUD para administración de estanques
    Route::prefix('admin/estanques')->group(function () {
        Route::get('/', [EstanqueController::class, 'index']); // Listar todos
        Route::get('/{id}', [EstanqueController::class, 'show']); // Ver uno específico
        Route::post('/', [EstanqueController::class, 'store']); // Crear
        Route::put('/{id}', [EstanqueController::class, 'update']); // Actualizar
        Route::delete('/{id}', [EstanqueController::class, 'destroy']); // Desactivar
        Route::patch('/{id}/activate', [EstanqueController::class, 'activate']); // Activar
    });

    Route::apiResource('/kpi-valores-entrada', KpiValoresEntradaController::class);
    Route::post('/calcular-kpis', [KpiCalculoController::class, 'calcular']);
    Route::get('/datos-mes-anterior', [InformeKpiController::class, 'obtenerValoresMesAnterior']);
    Route::get('/faenas-disponibles', [KpiCalculoController::class, 'getFaenasDisponibles']);
    Route::get('/kpis-comparativos', [KpiCalculoController::class, 'obtenerKpisComparativos']);
    Route::get('/kpis-getCostoPetroleoSinUltimosConsumos', [KpiCalculoController::class, 'getCostoPetroleoSinUltimosConsumos']);
    Route::get('/kpi-valores-entrada/verificar-permiso', [KpiValoresEntradaController::class, 'verificarPermiso']);
    Route::get('/kpi-valores-entrada-historial', [KpiValoresEntradaController::class, 'obtenerHistorial']);
    Route::get('/kpi-valores-entrada-historial', [KpiValoresEntradaController::class, 'getHistorialGeneral']);
    Route::get('/kpi-valores-entrada-historial/faena/{idFaena}', [KpiValoresEntradaController::class, 'getHistorialPorFaena']);
    Route::get('/kpi-estadisticas-por-faena', [KpiValoresEntradaController::class, 'getEstadisticasPorFaena']);
    Route::get('/kpi-totales-acumulados', [KpiValoresEntradaController::class, 'getTotalesAcumulados']);
    Route::get('/kpi-valores-entrada-historial-filtrado', [KpiValoresEntradaController::class, 'getHistorialFiltrado']);
    Route::get('/proyeccion-consumo', [ProyeccionConsumoController::class, 'getProyeccionAvanzada']);
    Route::get('/proyeccion-consumo/equipos', [ProyeccionConsumoController::class, 'getEquiposConUltimoConsumo']);
    Route::get('/proyeccion-consumo-ayer', [ProyeccionConsumoController::class, 'getMaquinasConConsumoHastaAyer']);
    Route::get('/consumo-resumen-fecha', [ProyeccionConsumoController::class, 'getResumenConsumoParaFecha']);
    Route::get('/proyeccion-consumo/rango', [ProyeccionConsumoController::class, 'getMaquinasConConsumoEnRango']);
    Route::get('/proyeccion-consumo/reporte', [ProyeccionConsumoController::class, 'getReporteProyeccionPorPeriodo']);
    Route::get('/proyeccion-test', [ProyeccionConsumoController::class, 'getKpisConProyeccion']);
    Route::get('/faenasTon', [TonelajeController::class, 'getFaenas']);
    Route::get('/faenasTon/{id}/padrones', [TonelajeController::class, 'getPadrones']);
    Route::get('/registros', [TonelajeController::class, 'getRegistros']);
    Route::post('/tonelajes', [TonelajeController::class, 'store']);
    Route::get('/tonelajes/{id}', [TonelajeController::class, 'show']);
    Route::put('/tonelajes/{id}', [TonelajeController::class, 'update']);
    Route::delete('/tonelajes/{id}', [TonelajeController::class, 'destroy']);
    Route::get('/tonelajes/{id}/historial', [TonelajeController::class, 'getHistorial']);
    Route::get('/tonelajes/{id}/puede-editar', [TonelajeController::class, 'puedeEditar']);
    Route::get('/reporte/pdf', [ReporteController::class, 'generarPDF']);


    // =====================================================
    // RUTAS PARA PIECHART DE CATEGORÍAS Y MÁQUINAS
    // =====================================================

    Route::prefix('categorias-chart')->group(function () {

        // Endpoint principal: datos para el piechart (categorías o máquinas según modo)
        Route::post('/datos', [CategoriasChartController::class, 'obtenerDatosCategoriasChart'])
            ->name('api.categorias-chart.datos');

        // Endpoint específico: solo categorías (más rápido)
        Route::post('/categorias', [CategoriasChartController::class, 'obtenerCategoriasResumen'])
            ->name('api.categorias-chart.categorias');

        // Endpoint específico: máquinas de una categoría (drill-down)
        Route::post('/categorias/{idCategoria}/maquinas', [CategoriasChartController::class, 'obtenerMaquinasCategoria'])
            ->name('api.categorias-chart.maquinas');
 
            // 🆕 NUEVO: Endpoint para viajes y distancias de camiones tolva
    Route::get('/camiones-viajes-distancias', [CategoriasChartController::class, 'obtenerViajesDistanciasCamionesTolva'])
        ->name('api.categorias-chart.camiones-viajes-distancias');


        // Endpoint auxiliar: lista de todas las categorías disponibles
        Route::get('/lista-categorias', [CategoriasChartController::class, 'obtenerListaCategorias'])
            ->name('api.categorias-chart.lista');

        // 🆕 AGREGAR ESTA RUTA FALTANTE:
        Route::get('/categorias/{idCategoria}/consumos-individuales', [CategoriasChartController::class, 'obtenerConsumosIndividualesCategoria'])
            ->name('api.categorias-chart.consumos-individuales');
    });

    // Rutas alternativas con nombres más cortos (opcional)
    Route::prefix('chart')->group(function () {
        Route::post('/categorias', [CategoriasChartController::class, 'obtenerCategoriasResumen']);
        Route::post('/maquinas/{idCategoria}', [CategoriasChartController::class, 'obtenerMaquinasCategoria']);
    });


    /*
    |--------------------------------------------------------------------------
    | 🚜 MÁQUINAS Y PERMISOS EN FAENAS
    |--------------------------------------------------------------------------
    */
    Route::prefix('maquinas-permisos')->group(function () {
        // Obtener todas las máquinas (con y sin permisos) - LEFT JOIN
        Route::get('/', [MaquinaPermisosController::class, 'index']);

        // Obtener solo máquinas que tienen permisos - INNER JOIN
        Route::get('/con-permisos', [MaquinaPermisosController::class, 'indexConPermisos']);

        // Obtener máquinas de una faena específica
        Route::get('/faena/{idFaena}', [MaquinaPermisosController::class, 'maquinasPorFaena']);

        // Estadísticas de máquinas y permisos
        Route::get('/estadisticas', [MaquinaPermisosController::class, 'estadisticas']);

        // Obtener todas las faenas disponibles
        Route::get('/faenas', [MaquinaPermisosController::class, 'getFaenas']);

        // Asignar permiso individual
        Route::post('/asignar', [MaquinaPermisosController::class, 'asignarPermiso']);

        // Remover permiso individual
        Route::delete('/remover', [MaquinaPermisosController::class, 'removerPermiso']);

        // Actualizar todos los permisos de una máquina (para el selector múltiple)
        Route::put('/actualizar', [MaquinaPermisosController::class, 'actualizarPermisos']);

        // Transferir máquina entre faenas (para drag & drop)
        Route::post('/transferir', [MaquinaPermisosController::class, 'transferirMaquina']);
        
    });
});

// Rutas para consumos
Route::get('/consumos/recientes', [ConsumoController::class, 'getConsumosRecientes']);
Route::get('/consumosFecha', [ConsumoController::class, 'getConsumos']);
Route::get('/consumos-categoria', [ConsumoController::class, 'getConsumosPorCategoria']);

// Rutas para dashboard
Route::get('/dashboard/stats', [IngresoPetroleoController::class, 'getStats']);

// En tu routes/api.php
Route::get('/recepcionesFecha', [IngresoPetroleoController::class, 'getRecepciones']);
