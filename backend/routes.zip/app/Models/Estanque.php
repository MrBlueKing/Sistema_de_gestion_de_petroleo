<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Estanque extends Model
{
    use HasFactory;

    protected $table = 'estanques';
    protected $primaryKey = 'id_estanque';
    public $incrementing = true;
    protected $keyType = 'int';

    protected $fillable = [
        'nombre',
        'tipo_estanque',
        'capacidad',
        'altura_nominal',
        'id_faena',
        'activo'
    ];

    // Relación con faena
    public function faena()
    {
        return $this->belongsTo(Faena::class, 'id_faena');
    }
    // Relación con EstanqueStock
    public function stock()
    {
        return $this->hasOne(EstanqueStock::class, 'id_estanque', 'id_estanque');
    }
    // Validación de capacidad al establecer stock_actual
    public function setStockActualAttribute($value)
    {
        // Obtener el estanque relacionado
        $estanque = $this->estanque;

        // Validar que no exceda la capacidad
        if ($estanque && $value > $estanque->capacidad) {
            throw new \Exception("El stock no puede exceder la capacidad del estanque ({$estanque->capacidad} litros)");
        }

        $this->attributes['stock_actual'] = $value;
    }
}
