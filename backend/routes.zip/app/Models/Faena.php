<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App\Models\PermisosMaquinasFaenas;
use App\Models\SolicitanteFaena;
use App\Models\PersonalInterno;
use App\Models\IngresoPetroleo;
use App\Models\OperadorVehiculo\CargaExterna;
use App\Models\User;
use Illuminate\Database\Eloquent\Relations\HasMany;

class Faena extends Model
{
    protected $primaryKey = 'id_faena';
    protected $table = 'faenas';

    // Campos que se pueden asignar masivamente
    protected $fillable = [
        'ubicacion',
        'detalle',
        'porcentaje_tributacion', // <- agregado
        'fecha_creacion',
    ];

    public $timestamps = false;

    // Relación con usuarios
    public function usuarios()
    {
        return $this->hasMany(User::class, 'id_faena');
    }

    // Relación con permisos de faena
    public function permisos()
    {
        return $this->hasMany(PermisosMaquinasFaenas::class, 'id_faena');
    }

    // Relación con ingresos de petróleo
    public function ingresosPetroleo()
    {
        return $this->hasMany(IngresoPetroleo::class, 'id_faena');
    }

    // Relación con SolicitanteFaena
    public function solicitanteFaenas()
    {
        return $this->hasMany(SolicitanteFaena::class, 'id_faena', 'id_faena');
    }

    // Relación muchos a muchos con Solicitante
    public function solicitantes()
    {
        return $this->belongsToMany(
            Solicitante::class,
            'solicitante_faena',
            'id_faena',     // Clave de la faena en la tabla pivot
            'id_dotacion'   // Clave del solicitante en la tabla pivot
        );
    }
    // Relación con padrones
    public function padrones()
    {
        return $this->hasMany(Padron::class, 'id_faena', 'id_faena');
    }
    // Relacion con tonelajes
    public function tonelajes()
    {
        return $this->hasManyThrough(Tonelaje::class, Padron::class, 'id_faena', 'id_padron', 'id_faena', 'id_padron');
    }

    /**
     * ✅ Relación con cargas externas
     */
    public function cargasExternas(): HasMany
    {
        return $this->hasMany(CargaExterna::class, 'ubicacion', 'id_faena');
        // Si renombraste la columna, cambia 'ubicacion' por 'id_faena'
    }
}
