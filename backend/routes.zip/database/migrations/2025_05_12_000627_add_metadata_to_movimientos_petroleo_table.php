<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::table('movimientos_petroleo', function (Blueprint $table) {
            // Añadir campo metadata para almacenar información adicional en formato JSON
            $table->json('metadata')->nullable()->after('id_usuario');
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::table('movimientos_petroleo', function (Blueprint $table) {
            $table->dropColumn('metadata');
        });
    }
};
